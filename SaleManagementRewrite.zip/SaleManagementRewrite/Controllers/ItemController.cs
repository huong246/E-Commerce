using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SaleManagementRewrite.Entities.Enum;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ItemController : ControllerBase
{
    private readonly IItemService _itemService;

    public ItemController(IItemService itemService)
    {
        _itemService = itemService;
    }

    [HttpPost("create_item")]
    [Authorize(Roles = nameof(UserRole.Seller))]
    public async Task<IActionResult> CreateItem([FromBody] CreateItemRequest request)
    {
        var result = await _itemService.CreateItemAsync(request);
        if (!result.IsSuccess)
        {
            return result.ErrorType switch
            {
                ErrorType.NotFound => NotFound(result.Error),
                ErrorType.Unauthorized => Unauthorized(result.Error),
                ErrorType.Conflict => Conflict(result.Error),
                _ => BadRequest(result.Error),
            };
        }

        return CreatedAtAction(nameof(GetItemById), new { id = result.Value });
    }
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetItemById(Guid id)
    {
        var item = await _itemService.GetItemByIdAsync(id);
        if (item == null)
        {
            return NotFound();
        }
        return Ok(item);
    }

    [HttpPost("update_item")]
    [Authorize(Roles = nameof(UserRole.Seller))]
    public async Task<IActionResult> UpdateItem([FromBody] UpdateItemRequest request)
    {
        var result = await _itemService.UpdateItemAsync(request);
        if (!result.IsSuccess)
        {
            return result.ErrorType switch
            {
                ErrorType.NotFound => NotFound(result.Error),
                ErrorType.Unauthorized => Unauthorized(result.Error),
                ErrorType.Conflict => Conflict(result.Error),
                _ => BadRequest(result.Error),
            };
        }

        return CreatedAtAction(nameof(GetItemById), new { id = result.Value });
    }
    
    [HttpDelete("delete_item")]
    [Authorize(Roles = $"{nameof(UserRole.Admin)}, {nameof(UserRole.Seller)}")]  
    public async Task<IActionResult> DeleteItem([FromBody] DeleteItemRequest request)
    {
        var result = await _itemService.DeleteItemAsync(request);
        return result.ErrorType switch
        {
            ErrorType.NotFound => NotFound(result.Error),
            ErrorType.Unauthorized => Unauthorized(result.Error),
            ErrorType.Conflict => Conflict(result.Error),
            ErrorType.Validation => BadRequest(result.Error),
            ErrorType.Failure => StatusCode(500, result.Error),
            _ => BadRequest(result.Error),
        };
    }
}
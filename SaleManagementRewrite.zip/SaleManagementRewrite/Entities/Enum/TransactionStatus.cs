namespace SaleManagementRewrite.Entities.Enum;

public enum TransactionStatus
{
    Pending,
    Completed,
    Failed,
}
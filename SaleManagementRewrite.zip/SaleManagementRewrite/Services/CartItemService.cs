using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using SaleManagementRewrite.Data;
using SaleManagementRewrite.Entities;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.Services;

public class CartItemService(IHttpContextAccessor httpContextAccessor, ApiDbContext dbContext)
    : ICartItemService
{
    public async Task<Result<CartItem>> AddItemToCart(AddItemToCartRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<CartItem>.Failure("Token invalid", ErrorType.Unauthorized);
        }

        var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            return Result<CartItem>.Failure("User not found", ErrorType.NotFound);
        }
        var shop = await dbContext.Shops.FirstOrDefaultAsync(s => s.UserId == userId);
        
        var item =  await dbContext.Items.Include(i => i.Shop).FirstOrDefaultAsync(i => i.Id == request.ItemId);
        if (item == null)
        {
            return Result<CartItem>.Failure("Item not found", ErrorType.NotFound);
        }

        if (shop != null)
        {
            if (item.ShopId == shop.Id)
            {
                return Result<CartItem>.Failure("Shop not permitted", ErrorType.Conflict);
            }
        }
        if (request.Quantity <= 0)
        {
            return Result<CartItem>.Failure("QuantityRequest invalid", ErrorType.Conflict);
        }

        if (request.Quantity > item.Stock && item.Stock > 0)
        {
            return Result<CartItem>.Failure("QuantityRequest invalid", ErrorType.Conflict);
        }

        if (item.Stock <= 0)
        {
            return Result<CartItem>.Failure("Out of stock", ErrorType.Conflict);
        }
        var cartItem = await dbContext.CartItems.FirstOrDefaultAsync(ci=>ci.ItemId == item.Id);
        if (cartItem != null)
        {
            cartItem.Quantity += request.Quantity;
            if (cartItem.Quantity > item.Stock)
            {
                return Result<CartItem>.Failure("Insufficient stock", ErrorType.Conflict);
            }
            dbContext.CartItems.Update(cartItem);
        }
        else
        {
            cartItem = new CartItem()
            {
                Id = Guid.NewGuid(),
                ItemId = item.Id,
                Item = item,
                ShopId = item.ShopId,
                Shop = item.Shop,
                Quantity = request.Quantity,
                User = user,
                UserId = userId,
            };
            dbContext.CartItems.Add(cartItem);
        }

        try
        {
            await dbContext.SaveChangesAsync();
            return Result<CartItem>.Success(cartItem);
        }
        catch (DbUpdateException)
        {
            return Result<CartItem>.Failure("Database error", ErrorType.Conflict);
        }
    }

    public async Task<Result<CartItem>> UpdateQuantityItem(UpdateQuantityItemInCartRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<CartItem>.Failure("Token invalid", ErrorType.Unauthorized);
        }

        var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            return Result<CartItem>.Failure("User not found", ErrorType.NotFound);
        }
        
        var item =  await dbContext.Items.FirstOrDefaultAsync(i => i.Id == request.ItemId);
        if (item == null)
        {
            return Result<CartItem>.Failure("Item not found", ErrorType.NotFound);
        }
        var cartItem = await dbContext.CartItems.FirstOrDefaultAsync(ci => ci.ItemId == request.ItemId && ci.UserId == userId); 
        if (cartItem == null) 
        { 
            return Result<CartItem>.Failure("CartItem not found", ErrorType.NotFound);
        }
        if (request.Quantity <= 0)
        {
            return Result<CartItem>.Failure("QuantityRequest invalid", ErrorType.Conflict);
        }

        if (item.Stock <= 0)
        {
            return Result<CartItem>.Failure("Out of stock", ErrorType.Conflict);
        }
        
        cartItem.Quantity+= request.Quantity;
        if (cartItem.Quantity > item.Stock)
        {
            return Result<CartItem>.Failure("Insufficient stock", ErrorType.Conflict);
        }

        try
        {
            dbContext.CartItems.Update(cartItem);
            await dbContext.SaveChangesAsync();
            return Result<CartItem>.Success(cartItem);
        }
        catch (DbUpdateException)
        {
            return Result<CartItem>.Failure("Database error", ErrorType.Conflict);
        }
    }

    public async Task<Result<bool>> DeleteItemFromCart(DeleteItemFromCartRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<bool>.Failure("Token invalid", ErrorType.Unauthorized);
        }

        var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            return Result<bool>.Failure("User not found",  ErrorType.NotFound);
        }
        
        var item =  await dbContext.Items.FirstOrDefaultAsync(i => i.Id == request.ItemId);
        if (item == null)
        {
            return Result<bool>.Failure("Item not found",  ErrorType.NotFound);
        }
        var cartItem = await dbContext.CartItems.FirstOrDefaultAsync(ci => ci.ItemId == item.Id && ci.UserId == userId);
        if (cartItem == null)
        {
            return Result<bool>.Failure("CartItem not found",  ErrorType.NotFound);
        }

        try
        {
            dbContext.CartItems.Remove(cartItem);
            await dbContext.SaveChangesAsync();
            return Result<bool>.Success(true);
        }
        catch (DbUpdateException)
        {
            return Result<bool>.Failure("Database error",  ErrorType.Conflict);
        }
    }
}
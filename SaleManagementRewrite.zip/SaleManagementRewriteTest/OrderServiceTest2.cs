using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Moq;
using SaleManagementRewrite.Data;
using SaleManagementRewrite.Entities;
using SaleManagementRewrite.Entities.Enum;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;
using SaleManagementRewrite.Services;

namespace SaleManagementRewriteTest;

public class OrderServiceTest2
{
    [Fact]
    public async Task GetOrderHistories_WhenRequestValid_ReturnsOrderHistories()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        var history1 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-3),
            FromStatus = null,
            ToStatus = nameof(OrderStatus.PendingPayment),
            Note = null,
        };
        var history2 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-2),
            FromStatus = nameof(OrderStatus.PendingPayment),
            ToStatus = nameof(OrderStatus.Paid),
            Note = null,
        };
        var history3 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-1),
            FromStatus = nameof(OrderStatus.Paid),
            ToStatus = nameof(OrderStatus.Delivered),
            Note = null,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.OrderHistories.AddRangeAsync(history1, history2, history3);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, customer.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var getOrderHistory = new GetOrderHistoryRequest(order.Id);
        var result = await orderService.GetOrderHistoryAsync(getOrderHistory);
        Assert.True(result.IsSuccess);
        Assert.NotNull(result.Value);
    }

    [Fact]
    public async Task GetOrderHistory_WhenNotPermitted_ReturnEmptyList()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        var history1 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-3),
            FromStatus = null,
            ToStatus = nameof(OrderStatus.PendingPayment),
            Note = null,
        };
        var history2 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-2),
            FromStatus = nameof(OrderStatus.PendingPayment),
            ToStatus = nameof(OrderStatus.Paid),
            Note = null,
        };
        var history3 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-1),
            FromStatus = nameof(OrderStatus.Paid),
            ToStatus = nameof(OrderStatus.Delivered),
            Note = null,
        };
        var userId2 = Guid.NewGuid();
        var user2 = new User()
        {
            Id = userId2,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address2 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId2,
            User = user2,
        };
        var shop2 = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user2,
            UserId = userId2,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, user2);
        await dbContext.Shops.AddRangeAsync(shop, shop2);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1, address2);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.OrderHistories.AddRangeAsync(history1, history2, history3);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user2.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var getOrderHistory = new GetOrderHistoryRequest(order.Id);
        var result = await orderService.GetOrderHistoryAsync(getOrderHistory);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);

    }

    [Fact]
    public async Task GetOrderHistory_WhenOrderNotFound_ReturnsOrderNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        var history1 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-3),
            FromStatus = null,
            ToStatus = nameof(OrderStatus.PendingPayment),
            Note = null,
        };
        var history2 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-2),
            FromStatus = nameof(OrderStatus.PendingPayment),
            ToStatus = nameof(OrderStatus.Paid),
            Note = null,
        };
        var history3 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-1),
            FromStatus = nameof(OrderStatus.Paid),
            ToStatus = nameof(OrderStatus.Delivered),
            Note = null,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.OrderHistories.AddRangeAsync(history1, history2, history3);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, customer.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var getOrderHistory = new GetOrderHistoryRequest(Guid.NewGuid());
        var result = await orderService.GetOrderHistoryAsync(getOrderHistory);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task GetOrderHistory_WhenTokenInvalid_ReturnsListEmpty()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        var history1 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-3),
            FromStatus = null,
            ToStatus = nameof(OrderStatus.PendingPayment),
            Note = null,
        };
        var history2 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-2),
            FromStatus = nameof(OrderStatus.PendingPayment),
            ToStatus = nameof(OrderStatus.Paid),
            Note = null,
        };
        var history3 = new OrderHistory()
        {
            Id = Guid.NewGuid(),
            Order = order,
            OrderId = order.Id,
            OrderItemId = orderItem.Id,
            OrderShopId = orderShop.Id,
            ChangedByUserId = customer.Id,
            CreateAt = DateTime.UtcNow.AddDays(-1),
            FromStatus = nameof(OrderStatus.Paid),
            ToStatus = nameof(OrderStatus.Delivered),
            Note = null,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.OrderHistories.AddRangeAsync(history1, history2, history3);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, "null")
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var getOrderHistory = new GetOrderHistoryRequest(order.Id);
        var result = await orderService.GetOrderHistoryAsync(getOrderHistory);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Unauthorized, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenRequestValid_ReturnsSuccess()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.True(result.IsSuccess);
        Assert.Equal(OrderShopStatus.Shipped, orderShop.Status);
    }

    [Fact]
    public async Task ShipOrderShop_WhenTokenInvalid_ReturnsTokenInvalid()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, "null")
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Unauthorized, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenUserNotFound_ReturnsUserNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenShopNotFound_ReturnsShopNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };

        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(Guid.NewGuid());
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenOrderNotFound_ReturnsOrderNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(Guid.NewGuid());
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenNotPermitted_ReturnsNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenConcurrencyConflict_ReturnsConcurrencyConflict()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task ShipOrderShop_WhenDatabaseError_ReturnsDatabaseError()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.ReadyToShop,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.ReadyToShop,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new ShipOrderShopRequest(orderShop.Id);
        var result = await orderService.ShipOrderShopAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenRequestValid_ReturnsSuccess()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.True(result.IsSuccess);
        Assert.Equal(OrderStatus.Canceled, order.Status);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenTokenInvalid_ReturnsTokenInvalid()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, "null")
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Unauthorized, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenUserNotFound_ReturnsUserNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenShopNotFound_ReturnsShopNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };

        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(Guid.NewGuid(), "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenOrderShopNotFound_ReturnsOrderNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(Guid.NewGuid(), "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenNotPermitted_ReturnsNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenConcurrencyConflict_ReturnsConcurrencyConflict()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task SellerCancelOrder_WhenDatabaseError_ReturnsDatabaseError()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.PendingPayment,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.PendingConfirmation,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Pending,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();

        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new SellerCancelOrderRequest(orderShop.Id, "testReason");
        var result = await orderService.SellerCancelOrderAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenRequestValid_ReturnsSuccess()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.True(result.IsSuccess);
        Assert.Equal(OrderShopStatus.Delivered, orderShop.Status);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenTokenInvalid_ReturnTokenInvalid()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, "null")
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Unauthorized, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenUserNotFound_ReturnsUserNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenNotPermitted_ReturnNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenOrderNotFound_ReturnOrderNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };

        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(Guid.NewGuid(), "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenNotPermittedState_ReturnsNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Completed,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenConcurrencyConflict_ReturnsConcurrencyConflict()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkShopOrderAsDelivered_WhenDatabaseError_ReturnsDatabaseError()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Paid,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Shipped,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-1),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Shipped,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new MarkShopOrderAsDeliveredRequest(orderShop.Id, "TestNote");
        var result = await orderService.MarkShopOrderAsDeliveredAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenRequestValid_ReturnsSuccess()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.True(result.IsSuccess);
        Assert.Equal(OrderStatus.Completed, order.Status);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenTokenInvalid_ReturnsTokenInvalid()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, "null")
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Unauthorized, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenUserNotFound_ReturnsUserNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenNotPermitted_ReturnsNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenOrderNotFound_ReturnsOrderNotFound()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(Guid.NewGuid());
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.NotFound, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenInvalidInstate_ReturnsNotPermitted()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Completed,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Completed,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Completed,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenReturnPeriodNotExpired_ReturnsReturnPeriodNotExpired()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        await using var dbContext = new ApiDbContext(options);
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-3),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Database.EnsureCreatedAsync();
        await dbContext.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Shops.AddAsync(shop);
        await dbContext.Items.AddAsync(item);
        await dbContext.Addresses.AddRangeAsync(address, address1);
        await dbContext.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Orders.AddAsync(order);
        await dbContext.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task? MarkEntireOrderAsCompleted_WhenConcurrencyConflict_ReturnsConcurrencyConflict()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }

    [Fact]
    public async Task MarkEntireOrderAsCompleted_WhenDatabaseError_ReturnsDatabaseError()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<ApiDbContext>().UseSqlite(connection).Options;
        var dbContext = new Mock<ApiDbContext>(options) { CallBase = true };
        var adminId = Guid.NewGuid();
        var admin = new User()
        {
            Id = adminId,
            Username = "123234567",
            UserRole = UserRole.Admin,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var userId = Guid.NewGuid();
        var user = new User()
        {
            Id = userId,
            Username = "123234567",
            UserRole = UserRole.Seller,
            Password = BCrypt.Net.BCrypt.HashPassword("123456789"),
            FullName = "John Doe",
            PhoneNumber = "0888888888",
        };
        var address = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = userId,
            User = user,
        };
        var shop = new Shop()
        {
            Id = Guid.NewGuid(),
            Address = address,
            AddressId = address.Id,
            Name = "shop",
            PrepareTime = 10,
            User = user,
            UserId = userId,
        };
        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = "item",
            Price = 100,
            Stock = 10,
            ShopId = shop.Id,
            Shop = shop,
            Description = "TestItem",
            Color = "blue",
            Size = "100",
        };
        var voucherShop = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = shop.Id,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shop,
            Value = 30,
            Quantity = 100,
        };
        var voucherShipping = new Voucher()
        {
            Id = Guid.NewGuid(),
            Code = "ABCDEFGHJK123",
            EndDate = DateTime.Now.AddDays(2),
            StartDate = DateTime.UtcNow,
            IsActive = true,
            ShopId = null,
            ItemId = null,
            Maxvalue = 100,
            MinSpend = 25,
            VoucherMethod = Method.FixAmount,
            VoucherTarget = Target.Shipping,
            Value = 30,
            Quantity = 100,
        };
        var customer = new User()
        {
            Id = Guid.NewGuid(),
            Username = "1232314567",
            UserRole = UserRole.Customer,
            Password = BCrypt.Net.BCrypt.HashPassword("12345116789"),
            FullName = "Joh1n Doe",
            PhoneNumber = "08818888888",
        };
        var address1 = new Address()
        {
            Id = Guid.NewGuid(),
            IsDefault = true,
            Latitude = 10.0,
            Longitude = 11.0,
            Name = "address",
            UserId = customer.Id,
            User = customer,
        };
        var order = new Order()
        {
            Id = Guid.NewGuid(),
            OrderDate = DateTime.UtcNow,
            DiscountProductAmount = 30,
            DiscountShippingAmount = 0,
            TotalAmount = 170,
            TotalShippingFee = 0,
            TotalSubtotal = 200,
            Status = OrderStatus.Delivered,
            VoucherProductId = null,
            VoucherShippingId = voucherShipping.Id,
            UserAddress = address1,
            User = customer,
            UserId = customer.Id,
            UserAddressId = address1.Id,
            OrderShops = new List<OrderShop>()
        };
        var orderShop = new OrderShop()
        {
            Id = Guid.NewGuid(),
            DiscountShopAmount = 30,
            ShopId = shop.Id,
            Shop = shop,
            ShippingFee = 0,
            Status = OrderShopStatus.Delivered,
            SubTotalShop = 200,
            TotalShopAmount = 170,
            VoucherShop = voucherShop,
            VoucherShopCode = "1234567890",
            VoucherShopId = voucherShop.Id,
            TrackingCode = Guid.NewGuid().ToString("N")[..10].ToUpper(),
            OrderItems = new List<OrderItem>(),
            Order = order,
            OrderId = order.Id,
            DeliveredDate = DateTime.UtcNow.AddDays(-8),
            Notes = null,
        };
        var orderItem = new OrderItem()
        {
            Id = Guid.NewGuid(),
            Quantity = 2,
            Item = item,
            ItemId = item.Id,
            Price = item.Price,
            ShopId = shop.Id,
            Shop = shop,
            Status = OrderItemStatus.Delivered,
            TotalAmount = 200,
            OrderShop = orderShop,
            OrderShopId = orderShop.Id,
        };
        orderShop.OrderItems.Add(orderItem);
        order.OrderShops.Add(orderShop);
        await dbContext.Object.Database.EnsureCreatedAsync();
        await dbContext.Object.Users.AddRangeAsync(user, customer, admin);
        await dbContext.Object.Shops.AddAsync(shop);
        await dbContext.Object.Items.AddAsync(item);
        await dbContext.Object.Addresses.AddRangeAsync(address, address1);
        await dbContext.Object.Vouchers.AddRangeAsync(voucherShipping, voucherShop);
        await dbContext.Object.Orders.AddAsync(order);
        await dbContext.Object.SaveChangesAsync();


        var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.NameIdentifier, adminId.ToString())
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var httpContext = new DefaultHttpContext
        {
            User = claimsPrincipal
        };
        mockHttpContextAccessor.Setup(m => m.HttpContext).Returns(httpContext);
        dbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException());
        var orderService = new OrderService(mockHttpContextAccessor.Object, dbContext.Object);
        var request = new MarkEntireOrderAsCompletedRequest(order.Id);
        var result = await orderService.MarkEntireOrderAsCompletedAsync(request);
        Assert.False(result.IsSuccess);
        Assert.Equal(ErrorType.Conflict, result.ErrorType);
    }
}
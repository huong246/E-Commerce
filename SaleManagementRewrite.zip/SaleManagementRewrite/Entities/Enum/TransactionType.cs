namespace SaleManagementRewrite.Entities.Enum;

public enum TransactionType
{
    Payment,
    Refund,
    PayoutToSeller,
    Deposit,
}
using System.Diagnostics;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using SaleManagementRewrite.Data;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.Services;

public class UserProfileService(IHttpContextAccessor httpContextAccessor, ApiDbContext dbContext)
    : IUserProfileService
{
    public async Task<Result<UserProfileDto>> GetUserProfileAsync()
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<UserProfileDto>.Failure("Token invalid", ErrorType.Unauthorized);
        }

        var userProfile = await dbContext.Users.Where(u => u.Id == userId)
            .Select(u => new UserProfileDto(u.Id, u.Username, u.FullName, u.PhoneNumber, u.Birthday, u.Gender))
            .FirstOrDefaultAsync();
        return userProfile == null ? Result<UserProfileDto>.Failure("User not found", ErrorType.NotFound) : Result<UserProfileDto>.Success(userProfile);
    }

    public async Task<Result<UserProfileDto>> UpdateUserProfileAsync(UpdateUserProfileRequest request)
    {
        var userIdString =  httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<UserProfileDto>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user =  await dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            return Result<UserProfileDto>.Failure("User not found", ErrorType.NotFound);
        }
        
        var noChanges = request.Fullname == user.FullName &&
                        request.Email == user.Email &&
                        request.PhoneNumber == user.PhoneNumber &&
                        request.Birthday == user.Birthday &&
                        request.Gender == user.Gender;

        if (noChanges)
        {
            return Result<UserProfileDto>.Failure("Duplicate value", ErrorType.Conflict);
        }

        user.FullName = request.Fullname ?? user.FullName;
        user.Email = request.Email ?? user.Email;
        user.PhoneNumber = request.PhoneNumber ?? user.PhoneNumber;
        user.Birthday = request.Birthday ?? user.Birthday;
        user.Gender = request.Gender ?? user.Gender;
        try
        {
            await dbContext.SaveChangesAsync();
            return Result<UserProfileDto>.Success(new UserProfileDto(userId, user.Username, user.FullName,
                user.PhoneNumber, user.Birthday, user.Gender));
        }
        catch (DbUpdateException)
        {
            return Result<UserProfileDto>.Failure("Database error", ErrorType.Conflict);
        }
    }

    public async Task<Result<bool>> UpdatePasswordAsync(UpdatePasswordRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<bool>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user =  await dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            return Result<bool>.Failure("User not found", ErrorType.NotFound);
        }

        if (!BCrypt.Net.BCrypt.Verify(request.OldPassword, user.Password))
        {
            return Result<bool>.Failure("OldPassword wrong", ErrorType.Conflict);
        }

        if (request.OldPassword == request.NewPassword)
        {
            return Result<bool>.Failure("Duplicate password", ErrorType.Conflict);
        }
        user.Password = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
        try
        {
            dbContext.Update(user);
            await dbContext.SaveChangesAsync();
            return Result<bool>.Success(true);
        }
        catch (DbUpdateException)
        {
            return Result<bool>.Failure("Database error", ErrorType.Conflict);
        }
    }
}
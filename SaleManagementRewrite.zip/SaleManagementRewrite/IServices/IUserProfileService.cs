using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.IServices;

 

public interface IUserProfileService
{
    Task<Result<UserProfileDto>> GetUserProfileAsync();
    Task<Result<UserProfileDto>> UpdateUserProfileAsync(UpdateUserProfileRequest request);
    Task<Result<bool>> UpdatePasswordAsync(UpdatePasswordRequest request);
}
namespace SaleManagementRewrite.Entities.Enum;

public enum RequestStatus
{
    Pending,
    Approved,
    Rejected,
}
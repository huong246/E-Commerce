using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.Controllers;

[ApiController]
[Route("[controller]")]
public class UserController(IUserService userService) : ControllerBase
{
    [HttpPost("register_user")]
    public async Task<IActionResult> RegisterUser([FromBody]RegisterRequest request)
    {
        var result = await userService.RegisterUser(request);
        return HandleResult(result);
    }

    [HttpPost("login_user")]
    public async Task<IActionResult> LoginUser([FromBody] LoginRequest request)
    {
        var result = await userService.LoginUser(request);
        return HandleResult(result);
    }

    [HttpPost("logout_user")]
    [Authorize]
    public async Task<IActionResult> LogoutUser()
    {
        var result = await userService.LogOutUser();
        return HandleResult(result);
    }
    private IActionResult HandleResult<T>(Result<T> result)
    {
        if (!result.IsSuccess)
        {
            return HandleFailure(result);
        }
        if (typeof(T) == typeof(bool))
        {
            return NoContent(); 
        }
        return Ok(result.Value);
    }
    private IActionResult HandleFailure<T>(Result<T> result)
    {
        return result.ErrorType switch
        {
            ErrorType.Validation => BadRequest(result.Error),
            ErrorType.NotFound => NotFound(result.Error),
            ErrorType.Conflict => Conflict(result.Error),
            ErrorType.Unauthorized => Unauthorized(result.Error),
            _ => StatusCode(500, result.Error)  
        };
    }
    
}
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using SaleManagementRewrite.Data;
using SaleManagementRewrite.Entities;
using SaleManagementRewrite.Entities.Enum;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;

namespace SaleManagementRewrite.Services;

public class ItemService(IHttpContextAccessor httpContextAccessor, ApiDbContext dbContext)
    : IItemService
{
    public async Task<Result<CreateItemResponse>> CreateItemAsync(CreateItemRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<CreateItemResponse>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user = await dbContext.Users.FirstOrDefaultAsync(u=>u.Id == userId);
        if (user == null)
        {
            return Result<CreateItemResponse>.Failure("User not found", ErrorType.NotFound);
        }
        var shop = await dbContext.Shops.FirstOrDefaultAsync(s => s.UserId == userId);
        if (shop == null)
        {
            return Result<CreateItemResponse>.Failure("shop not found", ErrorType.NotFound);
        }
        if (request.Stock <= 0 || request.Price < 0)
        {
            return Result<CreateItemResponse>.Failure("Quantity invalid", ErrorType.Conflict);
        }

        var item = new Item()
        {
            Id = Guid.NewGuid(),
            Name = request.Name,
            Stock = request.Stock,
            Price = request.Price,
            Description = request.Description,
            Color = request.Color,
            Size = request.Size,
            Shop = shop,
            ShopId = shop.Id,
        };
        try
        {
            await dbContext.Items.AddAsync(item);
            await dbContext.SaveChangesAsync();
            var response = new CreateItemResponse(item);
            return Result<CreateItemResponse>.Success(response);
        }
        catch (DbUpdateException)
        {
            return Result<CreateItemResponse>.Failure("Database error", ErrorType.Conflict);
        }
    }
    public async Task<Item?> GetItemByIdAsync(Guid id)
    {
        return await dbContext.Items
            .AsNoTracking()
            .FirstOrDefaultAsync(i => i.Id == id);
    }

    public async Task<Result<Item>> UpdateItemAsync(UpdateItemRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<Item>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user = await dbContext.Users.FirstOrDefaultAsync(u=>u.Id == userId);
        if (user == null)
        {
            return Result<Item>.Failure("User not found", ErrorType.NotFound);
        }
        var shop = await dbContext.Shops.FirstOrDefaultAsync(s => s.UserId == userId);
        if (shop == null)
        {
            return Result<Item>.Failure("Shop not found", ErrorType.NotFound);
        }
        var item = await dbContext.Items.FirstOrDefaultAsync(i=>i.Id ==request.ItemId && i.ShopId == shop.Id);
        if (item == null)
        {
            return Result<Item>.Failure("Item not found", ErrorType.NotFound);
        }
        bool noChange = ((request.Name == item.Name) || (request.Name == null))
                        && ((request.Stock == item.Stock) || (request.Stock == null))
                        && ((request.Price == item.Price) || (request.Price == null))
                        && ((request.Description == item.Description) || (request.Description == null))
                        && ((request.Size == item.Size) || (request.Size == null))
                        && ((request.Color == item.Color) || (request.Color == null));
        if (noChange)
        {
            return Result<Item>.Failure("Duplicate value", ErrorType.Conflict);
        }

        if (request.Price < 0 || request.Stock < 0)
        {
            return Result<Item>.Failure("Request invalid", ErrorType.Conflict);
        }
        item.Name = request.Name??item.Name;
        item.Stock = request.Stock ?? item.Stock;
        item.Price = request.Price ?? item.Price;
        item.Description = request.Description ?? item.Description;
        item.Color = request.Color ?? item.Color;
        item.Size = request.Size ?? item.Size;
        try
        {
            dbContext.Items.Update(item);
            await dbContext.SaveChangesAsync();
            return Result<Item>.Success(item);
        }
        catch (DbUpdateException)
        {
            return Result<Item>.Failure("Database error", ErrorType.Conflict);
        }
    }

    public async Task<Result<bool>> DeleteItemAsync(DeleteItemRequest request)
    {
        var userIdString = httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdString, out var userId))
        {
            return Result<bool>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user = await dbContext.Users.FirstOrDefaultAsync(u=>u.Id == userId);
        if (user == null)
        {
            return Result<bool>.Failure("User not found", ErrorType.NotFound);
        }

        if (user.UserRole == UserRole.Customer)
        {
            return Result<bool>.Failure("UserRole invalid", ErrorType.Conflict);
        }
        var shop = await dbContext.Shops.FirstOrDefaultAsync(s => s.UserId == userId);
        if (shop == null)
        {
            return Result<bool>.Failure("Shop not found", ErrorType.NotFound);
        }
        var item = await dbContext.Items.FirstOrDefaultAsync(i=>i.Id ==request.ItemId && i.ShopId == shop.Id);
        if (item == null)
        {
            return Result<bool>.Failure("Item not found", ErrorType.NotFound);
        }
        try
        {
            dbContext.Items.Remove(item);
            await dbContext.SaveChangesAsync();
            return Result<bool>.Success(true);
        }
        catch (DbUpdateException)
        {
            return Result<bool>.Failure("Database error", ErrorType.Conflict);
        }
    }
}
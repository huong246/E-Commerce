using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using SaleManagementRewrite.Data;
using SaleManagementRewrite.Entities;
using SaleManagementRewrite.Entities.Enum;
using SaleManagementRewrite.IServices;
using SaleManagementRewrite.Results;
using SaleManagementRewrite.Schemas;
using JwtRegisteredClaimNames = Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames;

namespace SaleManagementRewrite.Services;

public class UserService(
    ApiDbContext dbContext,
    IHttpContextAccessor httpContextAccessor,
    IConfiguration configuration,
    IMemoryCache cache)
    : IUserService
{
    public async Task<Result<User>> RegisterUser(RegisterRequest request)
    {
       var user = await dbContext.Users.FirstOrDefaultAsync(u =>u.Username == request.Username);
       if (user != null)
       {
           return Result<User>.Failure("Username already exists", ErrorType.Conflict);
       }

       if (request.Password.Length < 8)
       {
           return Result<User>.Failure("PasswordLength invalid",  ErrorType.Conflict);
       }

       user = new User()
       {
           Id = Guid.NewGuid(),
           Balance = 0,
           FullName = request.FullName,
           Username = request.Username,
           Password =BCrypt.Net.BCrypt.HashPassword(request.Password),
           PhoneNumber = request.PhoneNumber,
           UserRole = UserRole.Customer,
       };
       try
       { 
           await dbContext.Users.AddAsync(user);
           await dbContext.SaveChangesAsync();
           return Result<User>.Success(user);
       }
       catch (DbUpdateException)
       {
           return Result<User>.Failure("Database error",  ErrorType.Conflict);
       }
    }

    public async Task<Result<LoginResponse>> LoginUser(LoginRequest request)
    {
    var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Username == request.Username);
        if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.Password))
    {
        return Result<LoginResponse>.Failure("Username or Password wrong", ErrorType.Unauthorized);
    }

    var authClaim = new List<Claim>
        {
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
        };
        foreach (UserRole role in Enum.GetValues(typeof(UserRole)))
    {
        if (user.UserRole.HasFlag(role))
        {
            authClaim.Add(new Claim(ClaimTypes.Role, role.ToString()));
        }
    }

    var accessToken = GenerateAccessToken(authClaim);
    var refreshToken = GenerateRefreshToken();
        
    _= int.TryParse(configuration["Jwt:RefreshTokenExpiresInDays"], out var refreshTokenExpiresInDays);
    user.RefreshToken = refreshToken;
    user.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(refreshTokenExpiresInDays);
        
    await dbContext.SaveChangesAsync();
    var response = new LoginResponse(accessToken, refreshToken);
    return Result<LoginResponse>.Success(response);
    }
    private string GenerateAccessToken(IEnumerable<Claim> claims)
    {
        var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"] ?? string.Empty));
        var tokenExpires = DateTime.UtcNow.AddMinutes(Convert.ToDouble(configuration["Jwt:ExpiresInMinutes"]));

        var token = new JwtSecurityToken(
            issuer: configuration["Jwt:ValidIssuer"],
            audience: configuration["Jwt:ValidAudience"],
            expires: tokenExpires,
            claims: claims,
            signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
    private static string GenerateRefreshToken()
    {
        var randomNumber = new byte[64];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);
        return Convert.ToBase64String(randomNumber);
    }

    public async Task<Result<bool>> LogOutUser()
    {
        var username = httpContextAccessor.HttpContext?.User.Identity?.Name;
        if (username == null)
        {
            return Result<bool>.Failure("Token invalid", ErrorType.Unauthorized);
        }
        var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Username == username);
        if (user == null)
        {
            return Result<bool>.Failure("User not found", ErrorType.NotFound);
        }
        var jti = httpContextAccessor.HttpContext?.User.FindFirstValue(JwtRegisteredClaimNames.Jti);
        var exp =  httpContextAccessor.HttpContext?.User.FindFirstValue(JwtRegisteredClaimNames.Exp);
        if (jti != null || exp != null)
        {
            var expiryTime = DateTimeOffset.FromUnixTimeSeconds(long.Parse(exp ?? string.Empty));
            var cacheExpiry = expiryTime - DateTimeOffset.UtcNow;

            if (cacheExpiry > TimeSpan.Zero)
            {
                cache.Set(jti ?? string.Empty, "blacklisted", cacheExpiry);
            }
            if (cacheExpiry > TimeSpan.Zero)
            {
                cache.Set(jti ?? string.Empty, "blacklisted", cacheExpiry);
            }
        }

        user.RefreshToken = null;
        user.RefreshTokenExpiryTime = null;
        try
        {
            await dbContext.SaveChangesAsync();
            return Result<bool>.Success(true);
        }
        catch (DbUpdateException)
        {
            return Result<bool>.Failure("Database error", ErrorType.Conflict);
        }
    }
}